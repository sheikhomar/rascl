package animals;

public interface ReflectiveVisitable {
	public void accept(ReflectiveVisitor rv);
}
