package lab8;
import lab7.Type;

/** An interface for types, mine or yours, interchangeably. */
public interface TypeAttrs extends Type {
   public String getTypeString();
}
