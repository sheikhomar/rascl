package lab7;

public interface Type { 
}
