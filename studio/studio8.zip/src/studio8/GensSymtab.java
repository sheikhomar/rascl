package studio8;
import lab8.*;

public interface GensSymtab {
	public SymtabInterface genSymtab();

}
