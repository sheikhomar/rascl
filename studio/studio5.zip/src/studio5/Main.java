package studio5;

// $Id: Main.java 26 2010-05-08 18:06:55Z cytron $

/*
 * Replace this class as directed by the studio instructions with
 *   the Main class you annotated in Studio 4.
 */

public class Main {
	
	public static void main(String[] args) {
		System.err.println("You forgot to replace the Main.java file with your work from studio4!");
		System.err.println("Consult your studio instructions!");
		System.exit(-1);
	}
	
}